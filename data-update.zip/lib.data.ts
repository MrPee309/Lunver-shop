// lib.data.ts
export type Product = {
  id: string;
  slug: string;
  name: string;
  price: number;          // USD
  image: string;          // public/ path (NextJS: no domain)
  description: string;
  rating: number;         // 0–5
  reviews: number;
  inStock: boolean;
  colors?: string[];
  sizes?: string[];
};

export const products: Product[] = [
  {
    id: "p-jumpsuit-1379-purple",
    slug: "jumpsuit-1379-purple",
    name: "Backless Fitness Romper – Purple",
    price: 24.99,
    image: "/assets/products/jumpsuit-1379-purple.jpeg",
    description:
      "Sexy backless halter romper with push-up effect. High-stretch knit, quick-dry. Great for gym or going-out.",
    rating: 4.7,
    reviews: 15,
    inStock: true,
    colors: ["Purple", "Black", "White"],
    sizes: ["S", "M", "L", "XL"],
  },
  {
    id: "p-bikini-brown",
    slug: "bikini-brown",
    name: "Triangle Bikini Set – Brown",
    price: 16.99,
    image: "/assets/products/bikini-brown.jpeg",
    description:
      "Classic tie-side triangle bikini with removable pads. Soft, quick-dry fabric; adjustable fit.",
    rating: 4.6,
    reviews: 32,
    inStock: true,
    colors: ["Brown", "Black", "Green", "Red"],
    sizes: ["S", "M", "L"],
  },
  {
    id: "p-hearts-blue-pink",
    slug: "hearts-blue-pink",
    name: "Hearts Bikini – Blue/Pink",
    price: 18.99,
    image: "/assets/products/hearts-blue-pink.jpeg",
    description:
      "Cute braided-strap bikini with blue/pink heart print. Stretchy, comfy, quick-dry.",
    rating: 4.8,
    reviews: 21,
    inStock: true,
    colors: ["Blue/Pink"],
    sizes: ["S", "M", "L"],
  },
  {
    id: "p-underwire-green",
    slug: "underwire-green",
    name: "Underwire Bikini – Green",
    price: 21.99,
    image: "/assets/products/underwire-green.jpeg",
    description:
      "Supportive underwire bikini with V-neck top and cheeky bottom. Smooth, high-elastic fabric.",
    rating: 4.9,
    reviews: 18,
    inStock: true,
    colors: ["Green", "Black", "Red"],
    sizes: ["S", "M", "L"],
  },
];

// Handy: single product lookup (optional)
export const getProductBySlug = (slug: string) =>
  products.find((p) => p.slug === slug);
